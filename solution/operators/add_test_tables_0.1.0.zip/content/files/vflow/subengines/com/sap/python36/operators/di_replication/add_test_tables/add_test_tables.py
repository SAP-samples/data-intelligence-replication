
import logging
import os
import io
from datetime import datetime, timezone, timedelta
import pandas as pd

pd.set_option('mode.chained_assignment',None)

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s ;  %(levelname)s ; %(name)s ; %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)


def process(msg):

    att = dict(msg.attributes)
    att['operator'] = 'add_test_tables'

    api.logger.info("Process started. Logging level: {}".format(api.logger.level))

    now_str = datetime.now(timezone.utc).isoformat()
    rec = [[att['table']['name'],'H1']]

    att['table'] =  {"columns": [
        {"class": "string", "name": "TABLE_NAME", "nullable": False, "size": 100, "type": {"hana": "NVARCHAR"}},
        {"name": "SLICE_PERIOD", "nullable": True, "size": 2, "type": {"hana": "NVARCHAR"}}],
               "name": api.config.table_repos, "version": 1}

    api.send(outports[1]['name'], api.Message(attributes=att, body=rec))
    api.send(outports[0]['name'], log_stream.getvalue())
    log_stream.seek(0)
    log_stream.truncate()

    api.logger.debug('Process ended')
    api.send(outports[0]['name'], log_stream.getvalue())


inports = [{'name': 'data', 'type': 'message.table', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'data', 'type': 'message.table', "description": "data"}]

api.set_port_callback(inports[0]['name'], process)

