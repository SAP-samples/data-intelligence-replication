import os


import logging
import io
import random
from datetime import datetime, timezone
import re

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)


def process(msg):
    att = dict(msg.attributes)
    att['operator'] = 'block'

    # Create transaction id
    att['pid'] = int(datetime.utcnow().timestamp() * 1000000)

    package_size = int(api.config.package_size)

    # SQL Statement
    table = att['schema_name'] + '.' + att['table_name']
    if package_size > 0:
        sql = 'UPDATE TOP {packagesize} {table} SET \"DIREPL_STATUS\" = \'B\', \"DIREPL_PID\" = {pid} ' \
              'WHERE  \"DIREPL_STATUS\" = \'W\' OR \"DIREPL_STATUS\" IS NULL '.format(packagesize=package_size, table=table, pid=att['pid'])
    else:
        sql = 'UPDATE {table} SET \"DIREPL_STATUS\" = \'B\', \"DIREPL_PID\" = {pid} ' \
              'WHERE  \"DIREPL_STATUS\" = \'W\' OR \"DIREPL_STATUS\" IS NULL '.format(table=table, pid = att['pid'])

    api.logger.info('Update statement: {}'.format(sql))

    # Send sql to data
    api.send(outports[1]['name'], api.Message(attributes=att, body=sql))

    # Send logging to log-port
    api.send(outports[0]['name'], log_stream.getvalue())
    log_stream.seek(0)
    log_stream.truncate()


inports = [{'name': 'data', 'type': 'message', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'msg', 'type': 'message', "description": "msg with sql statement"}]

api.set_port_callback(inports[0]['name'], process)

