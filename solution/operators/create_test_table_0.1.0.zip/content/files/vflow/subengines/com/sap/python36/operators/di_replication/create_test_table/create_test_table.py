

import logging
import os
import io

import pandas as pd


pd.set_option('mode.chained_assignment',None)

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s ;  %(levelname)s ; %(name)s ; %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

def process(msg):

    att = dict(msg.attributes)
    operator_name = 'create_test_table'

    table_name = att['table_name']

    sql = "CREATE COLUMN TABLE {table} (\"INDEX\" BIGINT , \"NUMBER\" BIGINT,  \"DATETIME\" TIMESTAMP,\"" \
          "DIREPL_PID\" BIGINT , \"DIREPL_UPDATED\" LONGDATE, " \
          "\"DIREPL_STATUS\" NVARCHAR(1), \"DIREPL_TYPE\" NVARCHAR(1), " \
          "PRIMARY KEY (\"INDEX\",\"DIREPL_UPDATED\"));".format(table = table_name )

    api.logger.info('Create Table: {}'.format(sql))
    att['sql'] = sql
    api.send(outports[1]['name'], api.Message(attributes=att, body=sql))
    api.send(outports[0]['name'], log_stream.getvalue())
    log_stream.seek(0)
    log_stream.truncate()


inports = [{'name': 'input', 'type': 'message', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'sql', 'type': 'message', "description": "msg with sql"}]

api.add_generator( process)

