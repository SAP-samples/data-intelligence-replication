

import os
import io
import logging



# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s :  %(levelname)s : %(name)s : %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

tables = dict()
pointer = -1
num_roundtrips = 0
last_data_outcome = 0
first_round = True


## Reading the table Repository
def set_replication_tables(msg):
    global tables

    header = [c["name"] for c in msg.attributes['table']['columns']]
    tables = [{header[i]: v for i, v in enumerate(row)} for row in msg.body]

    # split the table name with schema into table and schema
    tables = [dict(t, **{'table_name': t['TABLE_NAME'].split('.')[1], 'schema_name': t['TABLE_NAME'].split('.')[0]}) for
              t in tables]

    att = {'num_tables': len(tables),'table_repository': msg.attributes['table']['name']}
    return process(api.Message(attributes=att, body=tables))


##
def nodata_process(msg):
    global tables
    global pointer

    msg.body = 'NODATA'

    if api.config.mode == 'R':
        # CONDITION: If there is no data processed than delete from table
        removed_table = tables[pointer]['table_name']
        del tables[pointer]
        pointer = pointer - 1 if pointer > 0 else len(tables) -1

        if len(tables) == 0: # No tables in tables-list left
            api.logger.info('Last Table removed from table-list: {}'.format(removed_table))
            api.send(outports[0]['name'], log_stream.getvalue())
            log_stream.seek(0)
            log_stream.truncate()
            msg = api.Message(attributes=msg.attributes, body='Number of roundtrips: {}'.format(num_roundtrips))
            api.send(outports[2]['name'], msg)
            return 0

        if pointer == len(tables) :
            pointer = 0
        api.logger.info('Table removed from table-list: {} '.format(removed_table, tables[pointer]['table_name']))

    process(msg)


## MAIN
def process(msg):
    global pointer
    global num_roundtrips
    global last_data_outcome
    global first_round

    att = dict(msg.attributes)

    att['operator'] = 'dispatch_tables'

    # case no repl tables provided
    if len(tables) == 0:
        api.logger.warning('No replication tables yet provided!')
        api.send(outports[0]['name'], log_stream.getvalue())
        log_stream.seek(0)
        msg = api.Message(attributes=att, body='Number of roundtrips: {}'.format(num_roundtrips))
        api.send(outports[2]['name'], msg)
        return 0

    # in case trigger ports body isn not 'NODATA' (None is not reliable) or ERROR
    if not msg.body == 'NODATA':
        last_data_outcome = num_roundtrips

    # end pipeline if there were no changes in all tables
    if (num_roundtrips - last_data_outcome) >= len(tables) and api.config.mode == 'C':
        api.logger.info('No changes after roundtrips: {}'.format(num_roundtrips))
        api.send(outports[0]['name'], log_stream.getvalue())
        log_stream.seek(0)
        msg = api.Message(attributes=att, body='Number of roundtrips: {}'.format(num_roundtrips))
        api.send(outports[2]['name'], msg)
        return 0

    # Get next table from table list
    pointer = (pointer + 1) % len(tables)
    if pointer == 0 and api.config.mode == 'F' and not first_round:
        api.logger.info('Input has been processed once: {}/{}'.format(len(tables), num_roundtrips))
        api.send(outports[0]['name'], log_stream.getvalue())
        log_stream.seek(0)
        msg = api.Message(attributes=att, body=num_roundtrips)
        api.send(outports[2]['name'], msg)
        return 0
    first_round = False
    repl_table = tables[pointer]
    att['table_name'] = repl_table['table_name']
    att['schema_name'] = repl_table['schema_name']

    # Send data to outport
    api.send(outports[1]['name'], api.Message(attributes=att, body=att['table_name']))

    # Send logging to 'log'- outport
    api.logger.info('Dispatch {}  roundtrip {}   last_action  {}'.format(att['table_name'], \
                                                                         num_roundtrips, \
                                                                         last_data_outcome))
    api.send(outports[0]['name'], log_stream.getvalue())
    log_stream.seek(0)
    log_stream.truncate()

    # Move pointer to next table in table list


    num_roundtrips += 1



inports = [{'name': 'tables', 'type': 'message.table', "description": "List of tables"},
           {'name': 'data', 'type': 'message.*', "description": "Trigger"},
           {'name': 'nodata', 'type': 'message', "description": "Trigger"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'trigger', 'type': 'message', "description": "trigger"},
            {'name': 'limit', 'type': 'message', "description": "limit"}]

api.set_port_callback(inports[0]['name'], set_replication_tables)
api.set_port_callback(inports[1]['name'], process)
api.set_port_callback(inports[2]['name'], nodata_process)


api.set_port_callback(inports[1]['name'], process)
api.set_port_callback(inports[0]['name'], set_replication_tables)

