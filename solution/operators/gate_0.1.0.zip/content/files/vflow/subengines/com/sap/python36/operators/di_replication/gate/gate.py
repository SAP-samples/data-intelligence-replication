
import os
import logging
import io



# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s -  %(levelname)s - %(name)s - %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)


inports = [ {"name": "data", "type": "message.*", "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {"name": "data", "type": "message", "description": "Output of unchanged last input data"}]

def call_on_message(msg):

    if 'message.lastBatch' in msg.attributes and msg.attributes['message.lastBatch'] == True:
        api.send(outports[1]['name'], msg)
        api.logger.info('Msg send to outports: Last batch in attributes')
    else:
        api.logger.info('No message send')

    api.logger.debug('Message Attributes: {}'.format(msg.attributes))
    api.send(outports[0]['name'], log_stream.getvalue())


api.set_port_callback(inports[0]['name'], call_on_message)


