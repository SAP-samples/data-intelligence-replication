import io
import logging
import os

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

def process(msg):
    att = dict(msg.attributes)
    att['operator'] = 'repl_checksum_col_attributes'

    if msg.body == None:
        api.logger.warning('No checksum column found: {} (Solution: file not in table repository)'.format(att))
        api.send(outports[0]['name'], log_stream.getvalue())
        att['checksum_col'] = ''
    else:
        att['checksum_col'] = msg.body[0][0]

    file_path_att = api.config.file_path_att
    if file_path_att == 'P' and len(att['current_file']['primary_key_file']) > 0:
        att['file']['path'] = os.path.join(att['current_file']['dir'], att['current_file']['primary_key_file'])
    elif file_path_att == 'B' and len(att['current_file']['base_file']) > 0:
        att['file']['path'] = os.path.join(att['current_file']['dir'], att['current_file']['base_file'])
    else:
        err_statement = "File path attribute wrongly set (P or B) not  {}!".format(api.config.file_path_att)
        api.logger.error(err_statement)
        raise ValueError(err_statement)

   # api.send(outports[1]['name'], update_sql)
    api.send(outports[1]['name'], api.Message(attributes=att, body=msg.body))

    log = log_stream.getvalue()
    if len(log) > 0:
        api.send(outports[0]['name'], log)


inports = [{'name': 'data', 'type': 'message.table', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'msg', 'type': 'message.*', "description": "msg"}]

api.set_port_callback(inports[0]['name'], process)

