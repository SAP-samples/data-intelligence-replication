
import io
import logging
import os

import re
import json

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)


table_collector = dict()
num_tables = 0
num_files = 0


def process(msg):
    global table_collector

    att = dict(msg.attributes)
    att['operator'] = 'repl_collect_files'

    api.logger.info("Process started")

    dir_name = os.path.dirname(att['file']['path'])
    filename = os.path.basename(att['file']['path'])
    schema_name = os.path.basename(os.path.dirname(dir_name))
    table_name = os.path.basename(dir_name)

    ## constructor collector structure
    if not schema_name in table_collector :
        table_collector[schema_name] = dict()
    if not table_name in table_collector[schema_name] :
        table_collector[schema_name][table_name] = {'dir':dir_name,'update_files':[],'base_file':'', 'schema_name':schema_name,\
                                                    'table_name':table_name,'primary_key_file':'','consistency_file':'','misc':[]}


    if filename == (table_name + '.csv') :
        table_collector[schema_name][table_name]['base_file'] = filename
    elif '_primary_keys.csv' in filename :
        table_collector[schema_name][table_name]['primary_key_file'] = filename
    elif '_ccheck.csv' in filename :
        table_collector[schema_name][table_name]['consistency_file'] = filename
    elif re.match('\d+_.*\.csv$',filename) :
        table_collector[schema_name][table_name]['update_files'].append(filename)
    else :
        table_collector[schema_name][table_name]['misc'].append(filename)


    api.logger.info('File collected: {}'.format(table_collector[schema_name][table_name]))

    if att['message.lastBatch'] == True:

        # flat structure
        files = [ b for a in list(table_collector.values()) for b in list(a.values())]

        api.logger.info('Send table collector. #files: {}'.format(len(table_collector)))
        api.logger.info('Process ended')
        msg = api.Message(attributes=att, body=files)
        api.send(outports[1]['name'], msg )

    log = log_stream.getvalue()
    if len(log)>0 :
        api.send(outports[0]['name'], log_stream.getvalue())

inports = [{'name': 'files', 'type': 'message.file', "description": "List of files"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'file', 'type': 'message.file', "description": "file"}]


api.set_port_callback(inports[0]['name'], process)


