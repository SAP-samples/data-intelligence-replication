import sdi_utils.gensolution as gs
import sdi_utils.set_logging as slog
import sdi_utils.textfield_parser as tfp
import sdi_utils.tprogress as tp

import subprocess
import logging
import os
import io
import random
from datetime import datetime, timezone, timedelta
import pandas as pd
import numpy as np

pd.set_option('mode.chained_assignment',None)


# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s :  %(levelname)s : %(name)s : %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

def process():

    operator_name = 'repl_create_test_tables'
    #logger, log_stream = slog.set_logging(operator_name, loglevel=api.config.debug_mode)

    api.logger.info("Process started. Logging level: {}".format(api.logger.level))
    time_monitor = tp.progress()

    for i in range (0,api.config.num_tables) :

        table_name = api.config.base_table_name + '_' + str(i)
        lastbatch = False if not i == api.config.num_tables - 1 else True

        ### DROP

        att_drop = {'table':{'name':table_name},'message.batchIndex':i,'message.lastBatch':lastbatch,'sql':'DROP'}
        api.logger.info("Drop table:")
        drop_sql = "DROP TABLE {table}".format(table = table_name)
        api.send(outports[1]['name'], api.Message(attributes=att_drop, body=drop_sql))
        api.send(outports[0]['name'], log_stream.getvalue())
        log_stream.seek(0)
        log_stream.truncate()

        ### CREATE

        api.logger.info('Create Table: ')

        create_sql = "CREATE COLUMN TABLE {table} (\"INDEX\" BIGINT , \"NUMBER\" BIGINT,  \"DATETIME\" TIMESTAMP,\
         \"DIREPL_PID\" BIGINT , \"DIREPL_UPDATED\" LONGDATE, " \
                     "\"DIREPL_STATUS\" NVARCHAR(1), \"DIREPL_TYPE\" NVARCHAR(1), " \
                     "PRIMARY KEY (\"INDEX\"));".format(table = table_name )

        att_create = {"table_name":table_name,'message.batchIndex':i,'message.lastBatch':lastbatch,'sql':create_sql}
        api.send(outports[1]['name'], api.Message(attributes=att_create, body=create_sql))
        api.send(outports[0]['name'], log_stream.getvalue())
        log_stream.seek(0)
        log_stream.truncate()

    api.logger.debug('Process ended: {}'.format(time_monitor.elapsed_time()))
    api.send(outports[0]['name'], log_stream.getvalue())


inports = [{'name': 'data', 'type': 'message.table', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'sql', 'type': 'message', "description": "msg with sql"}]

api.add_generator( process)

