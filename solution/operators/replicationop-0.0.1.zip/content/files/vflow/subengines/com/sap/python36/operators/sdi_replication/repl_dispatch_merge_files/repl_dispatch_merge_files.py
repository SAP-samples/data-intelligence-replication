import io

import os
import time

import subprocess

import sdi_utils.gensolution as gs
import sdi_utils.set_logging as slog
import sdi_utils.textfield_parser as tfp
import sdi_utils.tprogress as tp



file_index = 0

def on_files(msg) :
    global file_index
    att = dict(msg.attributes)
    att['operator'] = 'repl_dispatch_merge_files_on_files'
    att['message.last_update_file'] = False
    api.send(outports[1]['name'], api.Message(attributes=att, body=msg.body))
    
    # reset when base table received
    file_index = 0

def on_trigger(msg) :

    global file_index

    att = dict(msg.attributes)
    att['operator'] = 'repl_dispatch_merge_files_on_trigger'
    logger, log_stream = slog.set_logging(att['operator'], loglevel=api.config.debug_mode)

    files_list = msg.attributes['current_file']['update_files']

    att['message.index_update'] = file_index
    att['message.index_num'] = len(files_list)
    att['message.last_update_file'] = False
    if file_index == len(files_list) - 1 :
        att['message.last_update_file'] = True
        
    if file_index >= len(files_list) :
        raise ValueError('File index out of bound: {}'.format(att))
        
    att['file']['path'] = os.path.join(msg.attributes['current_file']['dir'],files_list[file_index])

    logger.info('Send File: {} ({}/{})'.format(files_list[file_index],file_index, len(files_list)))
    api.send(outports[1]['name'], api.Message(attributes=att,body=files_list[file_index]))
    api.send(outports[0]['name'], log_stream.getvalue())
    file_index += 1


inports = [{'name': 'files', 'type': 'message.file',"description":"List of files"},
           {'name': 'trigger', 'type': 'message.*',"description":"Trigger"}]
outports = [{'name': 'log', 'type': 'string',"description":"Logging data"}, \
            {'name': 'file', 'type': 'message.file',"description":"file"},
            {'name': 'limit', 'type': 'message',"description":"limit"}]


api.set_port_callback(inports[0]['name'], on_files)
api.set_port_callback(inports[1]['name'], on_trigger)



