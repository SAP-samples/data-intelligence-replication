import io
import logging
import os


# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)


file_index = -1

def on_target(msg) :
    global file_index
    att = dict(msg.attributes)
    att['operator'] = 'repl_dispatch_merge_files_on_target'
    att['message.last_update_file'] = False
    att['target_file'] = True
    api.send(outports[1]['name'], api.Message(attributes=att, body=msg.body))

    # reset when base table received
    file_index = -1

def on_init(msg) :
    global file_index
    # reset when base table received
    file_index = -1
    on_next(msg)

def on_next(msg) :

    global file_index

    att = dict(msg.attributes)
    att['operator'] = 'repl_dispatch_merge_files_on_trigger'

    files_list = msg.attributes['current_file']['update_files']
    file_index += 1
    att['message.index_update'] = file_index
    att['message.index_num'] = len(files_list)
    att['message.last_update_file'] = False
    att['target_file'] = False
    if file_index == len(files_list) - 1 :
        att['message.last_update_file'] = True
    if file_index >= len(files_list) :
        raise ValueError('File index out of bound: {}'.format(att))

    att['file']['path'] = os.path.join(msg.attributes['current_file']['dir'],files_list[file_index])

    api.logger.info('Send File: {} ({}/{})'.format(files_list[file_index],file_index, len(files_list)))
    api.send(outports[1]['name'], api.Message(attributes=att,body=files_list[file_index]))


    log = log_stream.getvalue()
    if len(log)>0 :
        api.send(outports[0]['name'], log_stream.getvalue())
        
        
inports = [{'name': 'target', 'type': 'message.file',"description":"Target file"},\
           {'name': 'init', 'type': 'message.file',"description":"Init"},\
           {'name': 'next', 'type': 'message.*',"description":"Next"}]
outports = [{'name': 'log', 'type': 'string',"description":"Logging data"}, \
            {'name': 'file', 'type': 'message.file',"description":"file"}]


api.set_port_callback(inports[0]['name'], on_target)
api.set_port_callback(inports[1]['name'], on_init)
api.set_port_callback(inports[2]['name'], on_next)

