import io
import logging


# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

def process(msg):

    att = dict(msg.attributes)
    att['operator'] = 'repl_get_checksum_col'

    api.logger.info("Process started")

    table_repos = api.config.replication_repos
    att['table_repository'] = table_repos
    if len(table_repos) == 0 :
        err_stat = 'Table Repository has been set in configuration!'
        api.logger.error(err_stat)
        raise ValueError(err_stat)

    table = att['schema_name'] + '.' + att['table_name']
    select_sql = 'SELECT \"CHECKSUM_COL\" FROM {repos}  WHERE \"TABLE_NAME\" = \'{table}\''.format(repos = table_repos, table = table)

    api.logger.info('Select statement: {}'.format(select_sql))
    att['select_sql'] = select_sql

    api.logger.debug("Process ended")

    #api.send(outports[1]['name'], update_sql)
    api.send(outports[1]['name'], api.Message(attributes=att,body=select_sql))

    log = log_stream.getvalue()
    if len(log) > 0 :
        api.send(outports[0]['name'], log )



inports = [{'name': 'data', 'type': 'message.table', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'msg', 'type': 'message', "description": "msg with sql statement"}]

api.set_port_callback(inports[0]['name'], process)

