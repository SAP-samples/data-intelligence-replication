import io
import time
import pandas as pd
import logging


# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)
# send log-stream
def send_log_stream() :
    api.send(outports[0]['name'], log_stream.getvalue())
    log_stream.seek(0)
    log_stream.truncate()
    
def send_adhoc_debug_log(str) :
    api.logger.debug(str)
    send_log_stream()

def process(msg) :

    att = dict(msg.attributes)
    att['operator'] = 'repl_get_primary_keys'
    
    send_adhoc_debug_log('Process started')
    
    header = [c["name"] for c in msg.attributes['table']['columns']]
    df = pd.DataFrame(msg.body,columns=header)
    repl_tables = df['TABLE_NAME'].values
    
    send_adhoc_debug_log('Tables: {}'.format(repl_tables))

    # case no repl tables provided
    if len(repl_tables) == 0 :
        api.logger.warning('No replication tables provided!')
        api.send(outports[0]['name'], log_stream.getvalue())
        raise ValueError('No replication tables provided!')
        
    send_adhoc_debug_log('Entering loop')
    for i,t in enumerate(repl_tables) :

        att_table = dict(att)

        lastbatch = False if not i == len(repl_tables) - 1 else True
        att_table['message.batchIndex'] = i
        att_table['message.lastBatch'] = lastbatch

        # split table from schema
        if '.' in t:
            att_table['table_name'] = t.split('.')[1]
            att_table['schema_name'] = t.split('.')[0]
        else:
            statment = 'No \"SCHEMA\" detected in table name!'
            api.logger.error(statment)
            raise ValueError(statment)

        sql = 'SELECT \"SCHEMA_NAME\", \"TABLE_NAME", \"COLUMN_NAME\" from SYS.\"CONSTRAINTS\" WHERE '\
              '\"SCHEMA_NAME\" = \'{schema}\' AND \"TABLE_NAME\" = \'{table}\' AND \"IS_PRIMARY_KEY\" = \'TRUE\''\
            .format(schema = att_table['schema_name'],table = att_table['table_name'])

        api.logger.info("Send msg: {}".format(sql))
        api.send(outports[1]['name'], api.Message(attributes=att_table,body=sql))
        api.send(outports[0]['name'], log_stream.getvalue())
        
        log_stream.seek(0)
        log_stream.truncate()
    
    api.logger.info('Process started')

    api.send(outports[0]['name'], log_stream.getvalue())
    
inports = [{'name': 'tables', 'type': 'message.table',"description":"List of tables"}]
outports = [{'name': 'log', 'type': 'string',"description":"Logging data"}, \
            {'name': 'sqlkeys', 'type': 'message',"description":"sql keys"}]
    
api.set_port_callback(inports[0]['name'], process)
