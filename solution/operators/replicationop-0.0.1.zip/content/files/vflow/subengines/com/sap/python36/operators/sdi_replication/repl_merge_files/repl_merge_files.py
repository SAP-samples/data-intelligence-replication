import io
import pandas as pd
import logging
import os


pd.set_option('expand_frame_repr', True)
pd.set_option('display.max_columns', 100)
pd.set_option('display.width', 200)

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

df = pd.DataFrame()


def process(msg):

    global df

    att = dict(msg.attributes)
    att['operator'] = 'repl_merge_files'

    csv_io = io.BytesIO(msg.body)
    if att['target_file'] :
        df = pd.read_csv(csv_io)
    else :
        df = df.append(pd.read_csv(csv_io), ignore_index=True)

    api.logger.debug('Update file: {} ({})'.format(df.shape[0],att['file']['path']))

    if att['message.last_update_file']:
        api.logger.debug('Last Update file - merge')
        #  cases:
        #  I,U: normal, U,I : should not happen, sth went wrong with original table (no test)
        #  I,D: normal, D,I : either sth went wrong in the repl. table or new record (no test)
        #  U,D: normal, D,U : should not happen, sth went wrong with original table (no test)

        # keep only the most updated records irrespective of change type I,U,D
        gdf = df.groupby(by = att['current_primary_keys'])['DIREPL_UPDATED'].max().reset_index()
        keys = att['current_primary_keys'] + ['DIREPL_UPDATED']
        df = pd.merge(gdf, df, on=keys, how='inner')

        # remove D-type records
        df = df.loc[~(df['DIREPL_TYPE']=='D')]

        # prepare for saving
        df = df[sorted(df.columns)]
        if df.empty :
            raise ValueError('DataFrame is empty - Avoiding to create empty file!')

        csv = df.to_csv(index=False)
        att['file']['path'] = os.path.join(att['current_file']['dir'], att['current_file']['base_file'])
        api.send(outports[1]['name'],api.Message(attributes=att, body=csv))

        # checksum
        repos_table = att['table_repository'] if 'table_repository' in att else ''
        checksum_col = att['checksum_col'] if 'checksum_col' in att else ''
        if not repos_table or not checksum_col :
            api.logger.warning('Checksum not setup checksum_col: {}  repository table: {}'.format(checksum_col,repos_table))
        else :
            checksum = df[checksum_col].sum()
            num_rows = df.shape[0]

            table = att['current_file']['schema_name'] + '.' +  att['current_file']['table_name']
            sql = 'UPDATE {repos_table} SET \"FILE_CHECKSUM\" = {cs}, \"FILE_ROWS\" = {nr}, \"FILE_UPDATED\" = CURRENT_UTCTIMESTAMP ' \
            ' WHERE \"TABLE_NAME\"  = \'{table}\' '.format(cs=checksum,nr = num_rows,repos_table = repos_table,table = table)
            api.logger.info("SQL statement for consistency update: {}".format(sql))
            att['sql'] = sql
            api.send(outports[3]['name'],api.Message(attributes=att, body=sql))
    else:
        api.send(outports[2]['name'], api.Message(attributes=att, body=''))

    log = log_stream.getvalue()
    if len(log)>0 :
        api.send(outports[0]['name'], log_stream.getvalue())

        
        
inports = [{'name': 'data', 'type': 'message.file', "description": "Input Data as csv"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'csv', 'type': 'message.file', "description": "Output data as csv"},
            {'name': 'next', 'type': 'message.file', "description": "Next file"},
            {'name': 'consistency', 'type': 'message', "description": "sql consistency update"}]


api.set_port_callback(inports[0]['name'], process)


