import io
import logging
import pandas as pd
import os

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)


def process(msg):

    att = dict(msg.attributes)
    att['operator'] = 'read_primary_key_file'

    ## read csv
    csv_io = io.BytesIO(msg.body)
    key_df = pd.read_csv(csv_io)

    att['current_primary_keys'] = key_df['COLUMN_NAME'].values.tolist()
    api.logger.info('Primary key: {}  ({})'.format(att['current_primary_keys'],att['current_file']['table_name']))
    att['file']['path'] = os.path.join(att['current_file']['dir'], att['current_file']['base_file'])

    msg = api.Message(attributes=att, body=att['current_file']['table_name'])
    api.send(outports[1]['name'], msg)

    log = log_stream.getvalue()
    if len(log)>0 :
        api.send(outports[0]['name'], log_stream.getvalue())

inports = [{'name': 'input', 'type': 'message.file', "description": "Input"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'base', 'type': 'message.file', "description": "Output"}]


api.set_port_callback(inports[0]['name'], process)

