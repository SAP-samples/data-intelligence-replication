
import os
import logging
import io


def read_list(text):

    result_list = list()
    #elem_list = text.split(sep)
    elem_list = text.split(',')
    for x in  elem_list:
        elem = int(x.strip())
        result_list.append(elem)

    return result_list

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)


def process(msg):

    att = dict(msg.attributes)
    att['operator'] = 'resetPID'

    if api.config.reset_all :
        sql = 'UPDATE {table} SET \"DIREPL_STATUS\" = \'W\'; '

    pid_list = read_list(api.config.pid_list)
    pid_where_list  = ' OR '.join(['DIREPL_PID = \'{}\''.format(i) for i in pid_list])
    sql = 'UPDATE {table} SET \"DIREPL_STATUS\" = \'W\' WHERE  {pid} ;'. \
        format(table=att['replication_table'], pid=pid_where_list)

    api.logger.info('Update statement: {}'.format(sql))
    att['sql'] = sql

    #api.send(outports[1]['name'], update_sql)
    api.send(outports[1]['name'], api.Message(attributes=att,body=sql))

    api.send(outports[0]['name'], log_stream.getvalue() )
    log_stream.seek(0)


inports = [{'name': 'data', 'type': 'message.file', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'msg', 'type': 'message', "description": "msg with sql statement"}]

api.set_port_callback(inports[0]['name'], process)

