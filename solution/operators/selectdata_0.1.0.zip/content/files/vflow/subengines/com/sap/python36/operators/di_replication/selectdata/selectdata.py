import os

import logging
import io


# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

def process(msg):

    att = dict(msg.attributes)
    att['operator'] = 'selectdata'
    table = att['schema_name'] + '.' + att['table_name']

    # Create SQL-statement
    sql = 'SELECT * FROM {table} WHERE \"DIREPL_STATUS\" = \'B\' AND  \"DIREPL_PID\" = \'{pid}\' '.\
        format(table=table,pid= att['pid'])
    api.logger.info('SELECT statement: {}'.format(sql))

    # Send to data-outport
    api.send(outports[1]['name'], api.Message(attributes=att,body = sql))

    # Send to log-outport
    api.send(outports[0]['name'], log_stream.getvalue() )
    log_stream.seek(0)
    log_stream.truncate()

inports = [{'name': 'trigger', 'type': 'message.table', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'msg', 'type': 'message', "description": "message with sql statement"}]

api.set_port_callback(inports[0]['name'], process)

