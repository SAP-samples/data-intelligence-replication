import os

import io
import pandas as pd
import logging
import json

pd.set_option('expand_frame_repr', True)
pd.set_option('display.max_columns', 100)
pd.set_option('display.width', 200)
# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)


def process(msg):

    att = dict(msg.attributes)
    att['operator'] = 'update_file'

    df = msg.body

    api.logger.debug('Update file: {} ({})'.format(df.shape[0],att['file']['path']))

    api.logger.debug('Last Update file - merge')
    #  cases:
    #  I,U: normal, U,I : should not happen, sth went wrong with original table (no test)
    #  I,D: normal, D,I : either sth went wrong in the repl. table or new record (no test)
    #  U,D: normal, D,U : should not happen, sth went wrong with original table (no test)

    # keep only the most updated records irrespective of change type I,U,D
    if not 'DIREPL_UPDATED' in att['primary_keys'] :
        api.logger.warning('DIREPL_UPDATED not part of primar key!')
    prim_keys = [p for p in att['primary_keys']  if not p == 'DIREPL_UPDATED']
    gdf = df.groupby(by = prim_keys)['DIREPL_UPDATED'].max().reset_index()
    df = pd.merge(gdf, df, on=att['primary_keys'], how='inner')

    # remove D-type records
    df = df.loc[~(df['DIREPL_TYPE']=='D')]

    # prepare for saving
    df = df[sorted(df.columns)]
    if df.empty :
        raise ValueError('DataFrame is empty - Avoiding to create empty file!')

    csv = df.to_csv(index=False)
    api.send(outports[1]['name'],api.Message(attributes=att, body=csv))


    log = log_stream.getvalue()
    if len(log)>0 :
        api.send(outports[0]['name'], log_stream.getvalue())

inports = [{'name': 'data', 'type': 'message.DataFrame', "description": "Input DataFrame"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'data', 'type': 'message.file', "description": "Output data"}]


api.set_port_callback(inports[0]['name'], process)


