import os

import logging
import io
import random
import pandas as pd
import numpy as np
from datetime import datetime, timezone

pd.set_option('mode.chained_assignment',None)

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

def process(msg):

    att = dict(msg.attributes)
    operator_name = 'insert_test_tables'

    if 'max_index' in att:
        max_index = att['max_index']
    else :
        max_index = api.config.num_updates

    maxn = 10000

    indices_update = random.sample(list(range(max_index)),k=api.config.num_updates)
    df = pd.DataFrame(indices_update, columns=['INDEX']).reset_index()
    df['NUMBER'] = np.random.randint(0, maxn, api.config.num_updates)
    df['DIREPL_UPDATED'] = datetime.now(timezone.utc).isoformat()
    df['DIREPL_PID'] = 0
    df['DIREPL_STATUS'] = 'W'
    df['DIREPL_TYPE'] = 'U'
    df['DATETIME'] =  datetime.now(timezone.utc) - pd.to_timedelta(1,unit='d')
    df['DATETIME'] = df['DATETIME'].apply(datetime.isoformat)

    table_name = att['schema_name']+'.'+att['table_name']
    att['table'] = {
        "columns": [{"class": "integer", "name": "INDEX", "nullable": False, "type": {"hana": "BIGINT"}}, \
                    {"class": "integer", "name": "NUMBER", "nullable": True, "type": {"hana": "BIGINT"}}, \
                    {"class": "datetime", "name": "DATETIME", "nullable": True, "type": {"hana": "TIMESTAMP"}}, \
                    {"class": "integer", "name": "DIREPL_PID", "nullable": True, "type": {"hana": "BIGINT"}}, \
                    {"class": "datetime", "name": "DIREPL_UPDATED", "nullable": True,"type": {"hana": "TIMESTAMP"}}, \
                    {"class": "string", "name": "DIREPL_STATUS", "nullable": True, "size": 1,"type": {"hana": "NVARCHAR"}}, \
                    {"class": "string", "name": "DIREPL_TYPE", "nullable": True, "size": 1,
                     "type": {"hana": "NVARCHAR"}}],"version": 1, "name": table_name}
    df = df[['INDEX', 'NUMBER', 'DATETIME','DIREPL_PID', 'DIREPL_UPDATED', 'DIREPL_STATUS','DIREPL_TYPE']]

    table_data = df.values.tolist()

    api.send(outports[1]['name'], api.Message(attributes=att, body=table_data))
    api.send(outports[0]['name'], log_stream.getvalue())
    log_stream.seek(0)


inports = [{'name': 'data', 'type': 'message.table', "description": "Input data"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'data', 'type': 'message.table', "description": "msg with sql"}]

api.set_port_callback(inports[0]['name'], process)

