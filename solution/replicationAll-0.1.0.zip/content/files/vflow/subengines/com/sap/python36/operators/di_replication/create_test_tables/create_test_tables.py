

import logging
import os
import io

import pandas as pd


pd.set_option('mode.chained_assignment',None)

# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s ;  %(levelname)s ; %(name)s ; %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

def process():

    operator_name = 'create_test_tables'

    # DROP TABLES
    for i in range(0, api.config.num_drop_tables):

        table_name = api.config.base_tablename + '_' + str(i)
        sql = "DROP TABLE {table}".format(table = table_name)
        att = {"table_name": table_name,
               'message.batchIndex': i,
               'message.lastBatch': False,
               'sql': sql,
               'table_basename': api.config.base_tablename,
               'num_new_tables': api.config.num_new_tables}
        api.logger.info("Drop table: {}".format(sql))

        api.send(outports[1]['name'], api.Message(attributes=att, body=sql))
        api.send(outports[0]['name'], log_stream.getvalue())
        log_stream.seek(0)
        log_stream.truncate()

    # CREATE TABLES and add to table repos
    for i in range (0,api.config.num_new_tables) :

        table_name = api.config.base_tablename + '_' + str(i)
        sql = "CREATE COLUMN TABLE {table} (\"INDEX\" BIGINT , \"NUMBER\" BIGINT,  \"DATETIME\" TIMESTAMP, "\
              "\"DIREPL_PID\" BIGINT , \"DIREPL_UPDATED\" LONGDATE, " \
              "\"DIREPL_STATUS\" NVARCHAR(1), \"DIREPL_TYPE\" NVARCHAR(1), " \
              "PRIMARY KEY (\"INDEX\",\"DIREPL_UPDATED\"));".format(table = table_name )
        api.logger.info('Create Table: {}'.format(sql))
        att = {"table_name": table_name,
               'message.batchIndex': i,
               'message.lastBatch': False,
               'sql': sql,
               'table_basename': api.config.base_tablename,
               'num_new_tables': api.config.num_new_tables}

        api.send(outports[1]['name'], api.Message(attributes=att, body=sql))
        api.send(outports[0]['name'], log_stream.getvalue())
        log_stream.seek(0)
        log_stream.truncate()


    #TRUNCATE TABLE REPOS
    sql = 'TRUNCATE TABLE {}'.format(api.config.table_repos)
    api.logger.info('TRUNCATE Table REPOSITORY: {}'.format(sql))
    att = {"table_name": table_name,
           'message.batchIndex': i,
           'message.lastBatch': False,
           'sql': sql,
           'table_basename': api.config.base_tablename,
           'num_new_tables': api.config.num_new_tables}
    api.send(outports[1]['name'], api.Message(attributes=att, body=sql))


    # ADD TABLES to Table Repository
    for i in range (0,api.config.num_new_tables) :
        lastbatch = False if not i == api.config.num_new_tables - 1 else True

        table_name = api.config.base_tablename + '_' + str(i)
        sql = "INSERT INTO {} VALUES(\'{}\',\'H1\')".format(api.config.table_repos,table_name)
        api.logger.info('INSERT Table into Table Repository: {}'.format(sql))
        att = {"table_name": table_name,
               'message.batchIndex': i,
               'message.lastBatch': lastbatch,
               'sql': sql,
               'table_basename': api.config.base_tablename,
               'num_new_tables': api.config.num_new_tables}

        api.send(outports[1]['name'], api.Message(attributes=att, body=sql))
        api.send(outports[0]['name'], log_stream.getvalue())
        log_stream.seek(0)
        log_stream.truncate()


outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'sql', 'type': 'message', "description": "msg with sql"}]

api.add_generator( process)

