

import io
import json
import os
import re

import pandas as pd
import logging


# catching logger messages for separate output
log_stream = io.StringIO()
sh = logging.StreamHandler(stream=log_stream)
sh.setFormatter(logging.Formatter('%(asctime)s |  %(levelname)s | %(name)s | %(message)s', datefmt='%H:%M:%S'))
api.logger.addHandler(sh)

def process(msg):

    att = dict(msg.attributes)

    att['operator'] = 'json_df'

    try :
        jdict = json.loads(msg.body)
        if not isinstance(jdict, list):
            jdict = [jdict]
    except json.decoder.JSONDecodeError :
        api.logger.warning('File not a valid JSON-file. Try to read it as JSON records line by line.')
        json_io = io.BytesIO(msg.body)
        jdict = [json.loads(line) for line in json_io]

    df = pd.DataFrame(jdict)

    msg = api.Message(attributes=att, body=df)
    api.send(outports[1]['name'], msg)
    api.send(outports[0]['name'], log_stream.getvalue())



inports = [{'name': 'stream', 'type': 'message.file', "description": "Input json byte or string"}]
outports = [{'name': 'log', 'type': 'string', "description": "Logging data"}, \
            {'name': 'data', 'type': 'message.DataFrame', "description": "Output DataFrame"}]


api.set_port_callback(inports[0]['name'], process)

